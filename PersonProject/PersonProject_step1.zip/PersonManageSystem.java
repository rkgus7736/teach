//Person 정보를 관리하는 시스템
public class PersonManageSystem {
	//Person 배열 선언
	
	//생성자
	
	//Person 정보 등록
	//Person 정보 삭제
	//Person 정보 수정
	//Person 정보 조회
	//Person 정보 전체 조회	
}
