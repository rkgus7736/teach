import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PersonManageSystem pms = new PersonManageSystem();
		while(true) {
			System.out.println("1. Person 정보 등록");
			System.out.println("2. Person 정보 삭제");
			System.out.println("3. Person 정보 수정");
			System.out.println("4. Person 정보 조회");
			System.out.println("5. Person 정보 전체 조회");
			System.out.println("0. 프로그램 종료");
			System.out.print("원하시는 메뉴 번호를 입력하세요 : ");
			int no = sc.nextInt();
			sc.nextLine();
			if(no == 0) break;
			
			switch(no) {
			case 1:
				pms.insertPerson(sc);
				break;
			case 4:
				pms.selectPerson(sc);
				break;
			case 5:
				pms.selectAllPerson();
				break;
			}
			
		}
	}

}



