import java.util.Arrays;
import java.util.Scanner;

//Person 정보를 관리하는 시스템
public class PersonManageSystem {
	//Person 배열 선언
	private Person[] arr;
	//배열 인덱스 - index
	private int index;

	//생성자
	public PersonManageSystem() {
		//배열 생성
		arr = new Person[7];
		//배열에 객체 생성
		arr[index++] = new Person("홍길동", 30);
		arr[index++] = new Person("김철수", 23);
		arr[index++] = new Person("박현우", 19);		
	}
	//Person 정보 등록
	public void insertPerson(Scanner sc) {
		System.out.println("Person 정보 등록을 시작합니다.");
		if(index == arr.length) {//배열에 빈공간이 없다.
			//배열의 크기 늘림
			arr = Arrays.copyOf(arr, arr.length+5);
		}
		//Person에 저장할 내용을 입력받아
		System.out.print("이름 : ");
		String name = sc.nextLine();
		System.out.println("나이 : ");
		int age = sc.nextInt();
		sc.nextLine();
		//Person을 생성하고
		Person p = new Person(name, age);
		//배열에 추가
		arr[index++] = p;
	}
	//Person 정보 삭제
	//Person 정보 수정
	//Person 정보 조회
	//Person 정보 전체 조회	
	public void selectAllPerson() {
		//전체 Person의 printInfo 실행
		for(int i=0;i<index;i++)
			arr[i].printInfo();
	}
}












