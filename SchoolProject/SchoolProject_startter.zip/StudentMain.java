
public class StudentMain {

	public static void main(String[] args) {
		StudentService service = new StudentService();
		 while(true) {
			 //메뉴 출력
			 //메뉴 번호 입력
			 
			 //해당 기능을 실행
			 
			 
		 }
	}

}
