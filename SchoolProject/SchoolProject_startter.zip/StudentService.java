
public class StudentService {
	//Student 배열 선언
	//Student 배열 인덱스
	
	//생성자
	//	배열길이 10 인 배열 생성
	
	//학생정보 추가
	//학생정보 삭제
	//학생정보 수정
	//학생정보 조회
	//학생정보 전체 조회
	
	//해당 학생 석차 구하는 부분
	
}
