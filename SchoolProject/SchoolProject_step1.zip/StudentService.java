import java.util.Arrays;
import java.util.Scanner;

public class StudentService {
	//Student 배열 선언
	private Student[] arr;
	//Student 배열 인덱스
	private int index;
	//생성자
	//	배열길이 10 인 배열 생성
	public StudentService() {
		super();
		arr = new Student[10];
	}
	//학생정보 추가
	public void insertStudent(Scanner sc) {
		if(index == arr.length)
			Arrays.copyOf(arr, arr.length+5);
		System.out.println("지금부터 학생 정보 추가를 시작합니다.......");
		//학번 이름 학과 평점 입력
		System.out.print("학번 입력 : ");
		String no = sc.nextLine();
		System.out.print("이름 입력 : ");
		String name = sc.nextLine();
		System.out.print("전공 입력 : ");
		String major = sc.nextLine();
		System.out.print("평점 입력 : ");
		double score = sc.nextDouble();
		//Student 생성
		Student std = new Student(no,name,major,score);
		//배열에 추가
		arr[index++] = std;
	}
	//학생정보 삭제
	//학생정보 수정
	//학생정보 조회
	//학생정보 전체 조회
	
	//해당 학생 석차 구하는 부분
	
}


