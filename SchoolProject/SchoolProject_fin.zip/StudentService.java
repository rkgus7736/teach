import java.util.Arrays;
import java.util.Scanner;

public class StudentService {
	//Student 배열 선언
	private Student[] arr;
	//Student 배열 인덱스
	private int index;
	//생성자
	//	배열길이 10 인 배열 생성
	public StudentService() {
		super();
		arr = new Student[10];
		arr[index++] = new Student("1001", "홍길동","컴퓨터공학과", 4.1);
		arr[index++] = new Student("1002", "이길동","경제학과", 3.1);
		arr[index++] = new Student("1003", "박길동","전자공학과", 4.2);
		arr[index++] = new Student("1004", "김길동","기계공학과", 1.3);
	}
	//학생정보 추가
	public void insertStudent(Scanner sc) {
		if(index == arr.length)
			Arrays.copyOf(arr, arr.length+5);
		System.out.println("지금부터 학생 정보 추가를 시작합니다.......");
		//학번 이름 학과 평점 입력
		System.out.print("학번 입력 : ");
		String no = sc.nextLine();
		System.out.print("이름 입력 : ");
		String name = sc.nextLine();
		System.out.print("전공 입력 : ");
		String major = sc.nextLine();
		System.out.print("평점 입력 : ");
		double score = sc.nextDouble();
		//Student 생성
		Student std = new Student(no,name,major,score);
		//배열에 추가
		arr[index++] = std;
	}
	//학생정보 삭제
	public void deleteStudent(Scanner sc) {
		System.out.println("학생 정보 삭제를 시작합니다.");
		System.out.print("삭제할 학생 번호 : ");
		String no = sc.nextLine();
		for(int i=0;i<index;i++) {
			if(arr[i].getSno().equals(no)) {
				for(;i<index-1;i++) {
					arr[i] = arr[i+1];
				}//for
				index--;
				System.out.println("삭제완료");
				return;//삭제완료
			}//if
		}//for
		System.out.println("삭제할 데이터가 없습니다.");
	}//deleteStudent

	//학생정보 수정
	public void updateStudent(Scanner sc) {
		System.out.println("학생정보 수정을 시작합니다.");
		System.out.print("수정할 학번 : ");
		String sno = sc.nextLine();
		for(int i=0;i<index;i++) {
			if(arr[i].getSno().equals(sno)) {
				System.out.print("수정할 이름 : ");
				String name = sc.nextLine();
				System.out.print("수정할 학과 : ");
				String major = sc.nextLine();
				System.out.print("수정할 평점 : ");
				double score = sc.nextDouble();
				arr[i].setName(name);
				arr[i].setMajor(major);
				arr[i].setScore(score);
				System.out.println("회원정보 수정 완료");
				return;
			}
		}
		System.out.println("수정할 데이터가 없습니다.");
	}
	//학생정보 조회 : 석차도 같이 출력
	public void selectStudent(Scanner sc) {
		//조회할 학번 입력
		String no = sc.nextLine();
		//조회
		for(int i=0;i<index;i++) {
			if(no.equals(arr[i].getSno())) {
				//학생정보 출력
				arr[i].printStudentInfo();
				//석차 정보 출력
				System.out.println(arr[i].getName() + "의 석차 : "
				+getRank(arr[i].getScore()));
			}
		}
	}
	//학생정보 전체 조회
	public void selectAllStudent() {
		for(int i=0;i<index;i++) {
			arr[i].printStudentInfo();
			System.out.println(arr[i].getName() + "의 석차 : "
					+getRank(arr[i].getScore()));
		}
	}
	//해당 학생 석차 구하는 부분
	public int getRank(double score) {
		int rank = 1;
		
		for(int i=0;i<index ;i++) {
			if(score < arr[i].getScore())
				rank++;
		}
				
		return rank;
	}
	
}//end of class







