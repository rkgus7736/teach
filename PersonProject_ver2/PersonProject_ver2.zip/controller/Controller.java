package controller;
import java.util.Scanner;

public class Controller {
	public void execute(Scanner sc) {}
}
